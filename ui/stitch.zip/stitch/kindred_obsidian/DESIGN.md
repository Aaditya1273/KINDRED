# Design System Strategy: The Luminous Void

## 1. Overview & Creative North Star
The Creative North Star for this design system is **"The Luminous Void."** 

Unlike standard fintech apps that rely on rigid grids and heavy borders to convey security, this system establishes authority through depth, atmosphere, and precision. We are moving away from the "app-template" look toward a **High-End Editorial** experience. By utilizing deep, obsidian-like surfaces juxtaposed with vibrant, glass-filtered accents, the interface feels less like a tool and more like a premium concierge service. 

To break the generic mold, we embrace:
*   **Intentional Asymmetry:** Overlapping glass cards and off-center typography to create a sense of motion.
*   **Tonal Breathability:** Extreme use of white space to allow the high-end typography to command the screen.
*   **Chromatic Depth:** Using the primary orange not just as a color, but as a light source that glows through translucent layers.

---

## 2. Colors & Surface Logic
The palette is rooted in a monochromatic dark base, punctuated by a high-energy orange that feels "charged" against the dark background.

### The "No-Line" Rule
**Explicit Instruction:** Designers are prohibited from using 1px solid borders to define sections. Traditional dividers are a sign of dated UI. Boundaries must be defined through:
1.  **Background Shifts:** Place a `surface_container_low` section against the main `surface` (#131314).
2.  **Tonal Transitions:** Use soft, linear gradients to transition from one functional area to the next.

### Surface Hierarchy & Nesting
Hierarchy is achieved through physical "stacking" of layers. Use the `surface_container` tiers to denote importance:
*   **Layer 0 (Base):** `surface` (#131314) – The infinite background.
*   **Layer 1 (Sections):** `surface_container_low` – Large structural areas.
*   **Layer 2 (Cards):** `surface_container` – Standard interactive units.
*   **Layer 3 (Floating/Popovers):** `surface_container_highest` – Temporary elements that require immediate focus.

### The "Glass & Gradient" Rule
Standard flat colors lack "soul." Main CTAs and featured widgets should utilize a transition from `primary` (#ffb693) to `primary_container` (#ff6b00). Floating elements must use **Glassmorphism**: a semi-transparent `surface_variant` with a 20px–40px backdrop blur to allow the background content to bleed through softly.

---

## 3. Typography: Editorial Authority
We use **Inter** as the foundational typeface, but we treat it with editorial intent.

*   **Display (Large Scale):** `display-lg` (3.5rem) should be used sparingly for "hero moments," such as account balances or high-level greetings. Use tight letter spacing (-0.02em) to create a powerful, "Apple-level" presence.
*   **Headline & Title:** `headline-md` (1.75rem) serves as the primary hook. It should always be `on_surface` (#e5e2e3) for maximum crispness.
*   **Body:** `body-lg` (1rem) is the workhorse. Ensure a line height of at least 1.5 to maintain the "Calm" atmosphere.
*   **Labels:** `label-md` (0.75rem) should be used for metadata. For a signature look, use `on_surface_variant` (#e2bfb0) with uppercase styling and increased letter spacing (0.05em) to differentiate from body text.

---

## 4. Elevation & Depth
Depth in this design system is "Atmospheric" rather than "Structural."

*   **The Layering Principle:** Instead of a shadow, place a `surface_container_lowest` (#0e0e0f) card on top of a `surface_container_low` (#1c1b1c) section. The subtle shift in hex value creates a soft, natural lift.
*   **Ambient Shadows:** When an element must "float" (like a Modal or Action Sheet), use an extra-diffused shadow:
    *   *Y-Offset:* 24px | *Blur:* 48px | *Color:* `on_surface` at 4% opacity. This mimics natural light reflecting off a matte surface.
*   **The "Ghost Border" Fallback:** If accessibility requires a container definition, use a **Ghost Border**. Use the `outline_variant` (#5a4136) at 15% opacity. Never use 100% opaque borders.
*   **Backdrop Blur:** All translucent cards must apply a `backdrop-filter: blur(24px)` to achieve the premium glass effect, ensuring that content beneath is obscured but the "light" still passes through.

---

## 5. Components

### Buttons
*   **Primary:** Background: Gradient (`primary` to `primary_container`). Radius: `full`. Text: `on_primary_fixed` (#351000).
*   **Secondary:** Background: `surface_container_highest`. Radius: `xl` (3rem). For a "High-End" feel, add a subtle Ghost Border.
*   **Tertiary:** Text-only using `primary`. No background. Used for low-priority "Cancel" or "Dismiss" actions.

### Cards & Lists
*   **Rule:** Forbid divider lines.
*   **Spacing:** Use `8` (2.75rem) or `10` (3.5rem) spacing between list items to create a luxury, "breathable" layout.
*   **Interaction:** On hover/tap, the card should shift from `surface_container` to `surface_bright` (#39393a).

### Input Fields
*   **Style:** Translucent backgrounds using `surface_container_low`.
*   **Roundedness:** `md` (1.5rem) for a modern, friendly feel.
*   **States:** On focus, the Ghost Border should animate to a subtle `primary` glow (2px outer blur).

### Signature Component: The "Glass Insight"
A specialized glassmorphic widget used for automatic fintech notifications. It uses a high-blur background with a subtle linear-gradient border (top-left to bottom-right) to catch the light, making it feel like a physical piece of glass resting on the screen.

---

## 6. Do's and Don'ts

### Do
*   **Do** use extreme vertical white space (Spacing `12` or `16`) to separate major conceptual sections.
*   **Do** utilize `primary_container` (#ff6b00) for "Action" moments (e.g., "Send Money," "Confirm").
*   **Do** use the `xl` (3rem) or `full` border radius for buttons to maintain the "Soft Minimalism" vibe.
*   **Do** ensure text contrast ratios are strictly followed, especially when using `on_surface_variant` on dark backgrounds.

### Don'ts
*   **Don't** use pure black (#000000). Use the system `surface` (#131314) to maintain tonal depth.
*   **Don't** use standard 1px dividers between list items. Use spacing or tonal shifts instead.
*   **Don't** use sharp corners. Every interactive element must have at least a `sm` (0.5rem) radius; buttons must be `xl` or `full`.
*   **Don't** use "flat" orange for large areas. Always apply a subtle gradient or "inner glow" to make the accent feel luminous.